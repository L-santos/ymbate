package com.example.clientoauth;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.net.URI;

@Service
@AllArgsConstructor
public class ResourceService {

    private final WebClient webClient;

    public Mono<String> getResource() {
        var uri = URI.create("http://localhost:8080/");
        return webClient.get()
                .uri(uri)
                .retrieve()
                .bodyToMono(String.class);
    }
}
