package com.example.clientoauth;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@AllArgsConstructor
public class ResourceController {

    private final ResourceService resourceService;

    @GetMapping("/get")
    public Mono<String> get(){
        return resourceService.getResource();
    }
}
