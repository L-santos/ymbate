package com.example.clientoauth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URI;

@Configuration
@SpringBootApplication
public class ClientOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientOauthApplication.class, args);
	}

//	@Bean
//	public ReactiveOAuth2AuthorizedClientManager authorizedClientManager(
//			ReactiveClientRegistrationRepository clientRegistrationRepository,
//			ReactiveOAuth2AuthorizedClientService authorizedClientService) {
//
//		ReactiveOAuth2AuthorizedClientProvider authorizedClientProvider =
//				ReactiveOAuth2AuthorizedClientProviderBuilder.builder()
//						.clientCredentials()
//						.password()
//						.build();
//
//		AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager authorizedClientManager =
//				new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(
//						clientRegistrationRepository, authorizedClientService);
//		authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);
//
//		return authorizedClientManager;
//	}
//
//	@Bean
//	public ReactiveClientRegistrationRepository reactiveClientRegistrationRepository(){
//		var client = ClientRegistration.withRegistrationId("app")
//				.clientId("authz-servlet")
//				.clientSecret("secret")
//				.authorizationGrantType(AuthorizationGrantType.PASSWORD)
//				.tokenUri("http://localhost:8095/realms/quickstart/protocol/openid-connect/token")
//				.build();
//		return new InMemoryReactiveClientRegistrationRepository(client);
//	}
}

@Component
class Runner implements ApplicationRunner {
	@Autowired
	WebClient webClient;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		var response = webClient.get()
				.uri("http://localhost:8080/")
				.retrieve()
				.bodyToMono(String.class)
				.block();
		System.out.println(response);
	}
}