package com.example.clientoauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
